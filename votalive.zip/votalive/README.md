# VotaLive — Presentes do TikTok LIVE viram votos

Painel de apuração em tempo real: cada presente enviado na LIVE conta pontos para o **Candidato A** ou **Candidato B**.

## Como rodar

```bash
cd votalive
npm install
npm start
```

Abra no navegador: **http://localhost:3000**

1. Digite o `@username` de quem está ao vivo no TikTok  
2. Clique em **Conectar à LIVE**  
3. Quando alguém mandar rosa, GG, Mini Dino, etc., o placar atualiza sozinho  

Os botões de presente na página continuam funcionando para **testar** sem LIVE.

## Mapa de presentes → pontos

| Presente              | Pontos | Candidato |
|-----------------------|--------|-----------|
| Rosa normal           | 10     | A         |
| GG                    | 10     | B         |
| Mini Dino             | 100    | A         |
| Rosa de 10 moedas     | 100    | B         |
| Mãos em coração       | 1.000  | A         |
| Urso Misha            | 1.000  | B         |

Para mudar nomes, pontos ou candidatos, edite o objeto `GIFT_MAP` em `server.js`.

## Requisitos

- Node.js 18+
- A conta precisa estar **ao vivo** no momento da conexão
- Internet (o servidor se conecta ao Webcast do TikTok)

## Arquivos

- `server.js` — escuta a LIVE com `tiktok-live-connector` e envia eventos via WebSocket
- `public/index.html` — painel visual (placar + atividade + botões de teste)
