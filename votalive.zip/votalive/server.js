/**
 * VotaLive — servidor que escuta presentes do TikTok LIVE
 * e envia para o painel no navegador em tempo real.
 *
 * Uso:
 *   1. npm install
 *   2. node server.js
 *   3. Abra http://localhost:3000
 *   4. Digite o @username da LIVE e clique em Conectar
 */

const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer } = require('ws');
const { TikTokLiveConnection, WebcastEvent, ControlEvent } = require('tiktok-live-connector');

const PORT = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.static(path.join(__dirname, 'public')));

// Mapeamento: nome do presente (minúsculo) → pontos e candidato
// Ajuste aqui se quiser mudar pontuação ou associação
const GIFT_MAP = {
  // Faixa 1 — 10 pontos
  'rose':           { votes: 10,   candidateId: 'A', emoji: '🌹', label: 'Rosa normal' },
  'rosa':           { votes: 10,   candidateId: 'A', emoji: '🌹', label: 'Rosa normal' },
  'gg':             { votes: 10,   candidateId: 'B', emoji: '🎮', label: 'GG' },

  // Faixa 2 — 100 pontos
  'mini dino':      { votes: 100,  candidateId: 'A', emoji: '🦖', label: 'Mini Dino' },
  'minidino':       { votes: 100,  candidateId: 'A', emoji: '🦖', label: 'Mini Dino' },
  'dino':           { votes: 100,  candidateId: 'A', emoji: '🦖', label: 'Mini Dino' },
  'rosa de 10 moedas': { votes: 100, candidateId: 'B', emoji: '🌹', label: 'Rosa de 10 moedas' },
  'rosa de 10':     { votes: 100,  candidateId: 'B', emoji: '🌹', label: 'Rosa de 10 moedas' },
  'big rose':       { votes: 100,  candidateId: 'B', emoji: '🌹', label: 'Rosa de 10 moedas' },
  'bigrose':        { votes: 100,  candidateId: 'B', emoji: '🌹', label: 'Rosa de 10 moedas' },

  // Faixa 3 — 1000 pontos
  'maos em coracao': { votes: 1000, candidateId: 'A', emoji: '🫶', label: 'Mãos em coração' },
  'mãos em coração': { votes: 1000, candidateId: 'A', emoji: '🫶', label: 'Mãos em coração' },
  'heart me':       { votes: 1000, candidateId: 'A', emoji: '🫶', label: 'Mãos em coração' },
  'heartme':        { votes: 1000, candidateId: 'A', emoji: '🫶', label: 'Mãos em coração' },
  'misha':          { votes: 1000, candidateId: 'B', emoji: '🧸', label: 'Urso Misha' },
  'urso misha':     { votes: 1000, candidateId: 'B', emoji: '🧸', label: 'Urso Misha' },
  'misha bear':     { votes: 1000, candidateId: 'B', emoji: '🧸', label: 'Urso Misha' },
  'bear':           { votes: 1000, candidateId: 'B', emoji: '🧸', label: 'Urso Misha' },
};

// Fallback por diamondCount (moedas) quando o nome não estiver no mapa
function mapByDiamonds(diamondCount) {
  if (diamondCount >= 100) return { votes: 1000, candidateId: null, emoji: '🎁', label: 'Presente especial' };
  if (diamondCount >= 10)  return { votes: 100,  candidateId: null, emoji: '🎁', label: 'Presente médio' };
  if (diamondCount >= 1)   return { votes: 10,   candidateId: null, emoji: '🎁', label: 'Presente simples' };
  return null;
}

function normalizeGiftName(name) {
  return String(name || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function resolveGift(giftName, diamondCount) {
  const key = normalizeGiftName(giftName);
  const diamonds = Number(diamondCount) || 0;

  // Rosa: 1 moeda = Lula (10); 10+ moedas = Flavio (100)
  if (key === 'rose' || key === 'rosa') {
    if (diamonds >= 10) {
      return { votes: 100, candidateId: 'B', emoji: '🌹', label: 'Rosa de 10 moedas' };
    }
    return { votes: 10, candidateId: 'A', emoji: '🌹', label: 'Rosa normal' };
  }

  if (GIFT_MAP[key]) return { ...GIFT_MAP[key] };

  // match parcial (mais longo primeiro, evita "dino" bater antes de "mini dino")
  const keys = Object.keys(GIFT_MAP).sort((a, b) => b.length - a.length);
  for (const mapKey of keys) {
    if (key.includes(mapKey) || mapKey.includes(key)) {
      return { ...GIFT_MAP[mapKey] };
    }
  }

  // fallback: pontos por diamante, sem candidato (não conta no placar)
  const byDiamond = mapByDiamonds(diamonds);
  if (byDiamond) {
    return { ...byDiamond, label: giftName || byDiamond.label };
  }
  return null;
}

let tiktokConnection = null;
let currentUsername = null;

function broadcast(payload) {
  const data = JSON.stringify(payload);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(data);
  }
}

function disconnectTikTok() {
  if (tiktokConnection) {
    try { tiktokConnection.disconnect(); } catch (_) {}
    tiktokConnection = null;
  }
  currentUsername = null;
}

async function connectTikTok(username) {
  disconnectTikTok();
  const clean = String(username || '').replace(/^@/, '').trim();
  if (!clean) throw new Error('Informe o @username da LIVE');

  const connection = new TikTokLiveConnection(clean, {
    processInitialData: false,
    enableExtendedGiftInfo: true,
  });

  connection.on(ControlEvent.CONNECTED, (state) => {
    currentUsername = clean;
    console.log(`[TikTok] Conectado em @${clean} (room ${state.roomId})`);
    broadcast({ type: 'status', status: 'connected', username: clean, roomId: state.roomId });
  });

  connection.on(ControlEvent.DISCONNECTED, () => {
    console.log(`[TikTok] Desconectado de @${clean}`);
    if (currentUsername === clean) {
      currentUsername = null;
      broadcast({ type: 'status', status: 'disconnected', username: clean });
    }
  });

  connection.on(ControlEvent.ERROR, (err) => {
    console.error('[TikTok] Erro:', err?.message || err);
    broadcast({ type: 'status', status: 'error', message: String(err?.message || err) });
  });

  connection.on(WebcastEvent.GIFT, (data) => {
    // Streak: só conta quando o combo termina (ou presente sem streak)
    const giftType = data.giftType ?? data.giftDetails?.giftType;
    const repeatEnd = data.repeatEnd;
    if (giftType === 1 && !repeatEnd) {
      // combo em andamento — ignora frames intermediários
      return;
    }

    const giftName =
      data.extendedGiftInfo?.name ||
      data.giftDetails?.giftName ||
      data.giftName ||
      `gift#${data.giftId}`;

    const diamondCount =
      data.extendedGiftInfo?.diamond_count ??
      data.giftDetails?.diamondCount ??
      data.diamondCount ??
      1;

    const repeatCount = Math.max(1, data.repeatCount || 1);
    const resolved = resolveGift(giftName, diamondCount);

    if (!resolved) {
      console.log(`[Gift ignorado] ${giftName} (${diamondCount}♦) x${repeatCount}`);
      broadcast({
        type: 'gift_ignored',
        giftName,
        diamondCount,
        repeatCount,
        user: data.user?.uniqueId || data.uniqueId || '?',
      });
      return;
    }

    const totalVotes = resolved.votes * repeatCount;
    const payload = {
      type: 'gift',
      giftName: resolved.label || giftName,
      emoji: resolved.emoji || '🎁',
      votes: totalVotes,
      pointsPerUnit: resolved.votes,
      repeatCount,
      candidateId: resolved.candidateId, // 'A' | 'B' | null
      diamondCount,
      user: data.user?.uniqueId || data.uniqueId || '?',
      nickname: data.user?.nickname || data.nickname || '',
    };

    console.log(
      `[Gift] ${payload.user} → ${payload.giftName} x${repeatCount} = +${totalVotes} pts` +
        (payload.candidateId ? ` → Candidato ${payload.candidateId}` : ' (sem candidato mapeado)')
    );
    broadcast(payload);
  });

  await connection.connect();
  tiktokConnection = connection;
  return clean;
}

wss.on('connection', (ws) => {
  console.log('[WS] Cliente conectado');
  ws.send(JSON.stringify({
    type: 'status',
    status: currentUsername ? 'connected' : 'idle',
    username: currentUsername,
  }));

  ws.on('message', async (raw) => {
    let msg;
    try { msg = JSON.parse(String(raw)); } catch { return; }

    if (msg.type === 'connect') {
      try {
        broadcast({ type: 'status', status: 'connecting', username: msg.username });
        await connectTikTok(msg.username);
      } catch (err) {
        console.error('[Connect]', err.message);
        broadcast({ type: 'status', status: 'error', message: err.message || String(err) });
      }
    }

    if (msg.type === 'disconnect') {
      disconnectTikTok();
      broadcast({ type: 'status', status: 'idle' });
    }
  });

  ws.on('close', () => console.log('[WS] Cliente saiu'));
});

server.listen(PORT, () => {
  console.log(`\n  VotaLive rodando em http://localhost:${PORT}`);
  console.log(`  Abra no navegador e digite o @ da LIVE.\n`);
});
